package spring.services;

public interface CustomerService {
		public double dispaly(int id,String name,double salary);
}
